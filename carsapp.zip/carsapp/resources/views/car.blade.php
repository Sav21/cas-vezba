@extends('layout.default')
@section('content')

{{$car->producer}}

@endsection