@extends('layout.default')
@section('content')
<h1>Welcome to Cars Project</h1>

<h1>Welcome {{$name}}</h1>
<p>I'm {{$age}} years old</p>
@endsection