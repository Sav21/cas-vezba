@extends('layout.default')
@section('content')

@foreach ($cars as $car)
<p>List of cars: ID <a href="/cars/{{$car->id}}">{{$car->id}}</a>  {{$car->title}}</p>
@endforeach

@endsection