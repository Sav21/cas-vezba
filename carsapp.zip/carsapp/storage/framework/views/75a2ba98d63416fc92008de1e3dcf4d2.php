<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layout.heading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="container mt-5, mb-5">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>


</html><?php /**PATH /Users/vivify/Desktop/drugi_cas/vezba2/carsapp/resources/views/layout/default.blade.php ENDPATH**/ ?>