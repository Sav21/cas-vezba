<?php $__env->startSection('content'); ?>

<?php echo e($car->producer); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/drugi_cas/vezba2/carsapp/resources/views/car.blade.php ENDPATH**/ ?>