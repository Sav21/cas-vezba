<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p>List of cars: ID <a href="/cars/<?php echo e($car->id); ?>"><?php echo e($car->id); ?></a>  <?php echo e($car->title); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/drugi_cas/vezba2/carsapp/resources/views/cars.blade.php ENDPATH**/ ?>