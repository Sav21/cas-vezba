<?php $__env->startSection('content'); ?>
<h1>Welcome to Cars Project</h1>

<h1>Welcome <?php echo e($name); ?></h1>
<p>I'm <?php echo e($age); ?> years old</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/drugi_cas/vezba2/carsapp/resources/views/welcome.blade.php ENDPATH**/ ?>